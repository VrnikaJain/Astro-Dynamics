import numpy as np

def degrees_to_radians(degrees):
    return np.radians(degrees)

def radians_to_degrees(radians):
    return np.degrees(radians)
