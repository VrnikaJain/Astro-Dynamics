MU_EARTH = 398600  # Standard gravitational parameter for Earth (km^3/s^2)
R_EARTH = 6371  # Radius of Earth (km)
